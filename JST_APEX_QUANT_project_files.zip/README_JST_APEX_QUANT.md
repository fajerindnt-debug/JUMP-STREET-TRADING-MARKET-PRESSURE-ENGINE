# JUMP STREET TRADING — Quant Research Dashboard

## Files
- `app.py`: Streamlit dashboard currently wired to the Market Pressure research view.
- `market_pressure.py`: missing dependency required by `app.py`; OHLC-derived pressure proxy.
- `jst_advanced_quant.py`: advanced statistical/probability/risk research helpers.
- `jst_3d_visualization.py`: Plotly 3D research visualizations.
- `test_jst_advanced_quant.py`: unit tests for the Advanced Quant module.
- `requirements.txt`: Python dependencies.

## Run locally
```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Set the Twelve Data key as an environment variable:
```bash
export TWELVE_DATA_API_KEY="YOUR_KEY"
```
On Streamlit Community Cloud, add this to **App → Settings → Secrets**:
```toml
TWELVE_DATA_API_KEY = "YOUR_KEY"
```
Do not commit API keys to GitHub.

## Important scope note
This bundle completes the missing `market_pressure.py` dependency for the currently available `app.py`.
It does **not** yet claim that the supplied V8.5 scanner has been integrated into the dashboard.
The original V8.5 strategy rules (BUY/SELL scoring, SL/TP, cooldown, paper-trade outcome and journal)
must remain unchanged during that separate integration. The OHLC-derived Market Pressure module is
a separate research/display proxy and is not exchange order flow.

## Research limitations
- OHLC candle pressure is not order-book imbalance or aggressor-side volume.
- Monte Carlo outputs depend on their statistical assumptions and are not price forecasts.
- Historical probabilities are not guaranteed future probabilities.
- Confirm API availability, completed-candle handling, costs, and out-of-sample performance before use.
- No broker order execution is implemented.
